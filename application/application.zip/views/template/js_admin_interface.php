<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/global/plugins/jquery.min.js')?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/jQueryUI/jquery-ui-1.10.3.js')?>" type="text/javascript"></script>


<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/global/plugins/bootstrap/js/bootstrap.min.js')?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/global/plugins/js.cookie.min.js')?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js')?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js')?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/global/plugins/jquery.blockui.min.js')?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js')?>" type="text/javascript"></script>
<!-- END CORE PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/global/plugins/moment.min.js')?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/global/plugins/morris/morris.min.js')?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/global/plugins/morris/raphael-min.js')?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/global/plugins/select2/js/select2.full.min.js')?>" type="text/javascript"></script>
<?php for ($i=0; $i < sizeof($plugin_foot) ; $i++) {?>
  <script src="<?php echo $plugin_foot[$i];?>" type="text/javascript"></script>
<?php }?>

<!-- END PAGE LEVEL PLUGINS -->
<!-- BEGIN THEME GLOBAL SCRIPTS -->
<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/global/scripts/app.min.js')?>" type="text/javascript"></script>
<!-- END THEME GLOBAL SCRIPTS -->
<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/pages/scripts/dashboard.min.js')?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/pages/scripts/components-select2.min.js')?>" type="text/javascript"></script>
<!-- END PAGE LEVEL SCRIPTS -->


<!-- BEGIN THEME LAYOUT SCRIPTS -->
<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/layouts/layout/scripts/layout.min.js')?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/layouts/layout/scripts/demo.min.js')?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/metronic_v4.5.6/theme/assets/layouts/global/scripts/quick-sidebar.min.js')?>" type="text/javascript"></script>
